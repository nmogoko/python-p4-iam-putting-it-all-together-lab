from sqlalchemy.orm import validates
from sqlalchemy.ext.hybrid import hybrid_property
from sqlalchemy_serializer import SerializerMixin
from config import db
from werkzeug.security import generate_password_hash, check_password_hash

class User(db.Model, SerializerMixin):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String, nullable=False, unique=True)
    _password_hash =db.Column(db.String, nullable=False)
    image_url =db.Column(db.String, nullable=True)
    bio =db.Column(db.String, nullable=True)
    recipes = db.relationship('Recipe', back_populates='user', cascade="all, delete-orphan")


    def __repr__(self):
        return f"<User(username='{self.username}', bio='{self.bio}', image_url='{self.image_url}')>"
    
    # Getter for password hash
    @property
    def password_hash(self):
        raise AttributeError("Password is not a readable attribute")

    # Setter for password hash
    @password_hash.setter
    def password_hash(self, password):
        if password is not None:  # Ensure password is not empty
            self._password_hash = generate_password_hash(password)
        else:
            raise ValueError("Password cannot be empty")

class Recipe(db.Model, SerializerMixin):
    __tablename__ = 'recipes'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    title = db.Column(db.String, nullable=False)
    instructions =db.Column(db.String, nullable=False)
    minutes_to_complete =db.Column(db.Integer, nullable=True)
    _user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)

    # Relationship to User
    user = db.relationship('User', back_populates='recipes')

    # Getter for password hash
    @property
    def user_id(self):
        return self._user_id 

    # Setter for password hash
    @user_id.setter
    def user_id(self, id):
        if id is not None:  
            self._user_id = id
        else:
            raise ValueError("User Id cannot be empty")

    def __repr__(self):
        return f"<Recipe(name='{self.name}')>"

    @validates('instructions')
    def validate_instructions(self, key, instruction):
        if len(instruction) < 50:
            raise ValueError("The instruction must be at least 50 characters long.")
        return instruction
   
    
  